﻿using System;

namespace ClassesEmployee
{
    class StartUp
    {
        static void Main(string[] args)
        {
            Employee employee = new Employee();

        }
    }

}
