﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassesEmployee
{
    public class Employee
    {
        private string name;
        private int age;

        public string Name { get => name; set => name = value; }
        public int Age { get => age; set => age = value; }
        public Employee()
        {
            this.Name = "Dan";
            this.Age = 20;
            this.Name = "Joey";
            this.Age = 18;
            this.Name = "Tommy";
            this.Age = 43;
        }
    }

}